# Place the Future State Data Model .docx here

This directory should contain:

- `future-state-data-model-v1.docx` — the canonical 50-page data model spec built with Claude

The file Christina has locally is currently named `Adira_Reads_Future_State_Data_Model_v1.docx`. Either copy it here as-is, or rename it to `future-state-data-model-v1.docx` to match the references in `docs/data-model.md`.

Without this file, the bundle is incomplete. The markdown files reference this document repeatedly as the source of truth for entity specs, the six-layer architecture, the Big Four metric formulas, the cliff alert hazard rates, the banding archetype profiles, and the 20+ open questions that have not yet been answered.

Delete this `PLACE_DOCX_HERE.md` file once you've added the .docx.
