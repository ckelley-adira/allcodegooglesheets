# Brand & Visual Identity

> **Critical rule:** TILT has multiple brand palettes for different contexts. **Always confirm with Christina which palette to use** before applying colors to any new artifact. Do not assume.

---

## TILT brand colors (current Tutor Input Form CSS)

These are the canonical colors from the current platform's CSS. Use these for **operational Adira Reads UI** (the school-facing platform):

| Role | Color | Hex | Notes |
|---|---|---|---|
| **Primary accent** | Mint / Seafoam | `#B8E6DC` | The "TILT teal" — primary brand color |
| **Action / emphasis** | Coral | `#FF6B6B` | Calls-to-action, alerts, highlights |
| **Text** | Near-Black | `#2C2C2C` | Body text and headings |
| **Background** | Off-White | `#FAF9F7` | Page background, card surfaces |
| **Highlight gradient** | Purple | `#667eea → #764ba2` | Used sparingly for emphasis or hero elements |

The TILT website also uses a **dusty plum** on buttons. **Confirm with Christina before using it** — it's part of the system but its scope is unclear.

## Status / threshold colors (fidelity scoring & dashboards)

The Friday Dashboard and fidelity scoring use Green/Yellow/Red bands. The current system uses standard semantic colors for these. Specific hex values should be confirmed before implementation but:

- **Green** = on track / Green threshold met (Big Four metrics, fidelity green)
- **Yellow** = warning / approaching threshold
- **Red** = below yellow threshold / requires attention

Pair these with the TILT palette so the dashboards feel branded, not generic.

---

## Other brand systems (NOT for the Adira Reads platform)

Christina has multiple brands. Do not cross-pollinate.

### @parentingmyparents (personal Instagram brand)
- **Deep Navy** / **Warm Cream** / **Warm Gold** palette
- **Playfair Display** / **Lato** typography
- This is Christina's caregiving content brand. **Not for use in the Adira Reads platform** — it would confuse the operational identity.

### Bridge Builder Consulting (her consulting concept)
- Has its own playbook — not specified here
- Different audience (small women-owned businesses)
- **Not for use in the Adira Reads platform**

---

## Typography

The current platform uses system fonts and basic web-safe stacks. There is **no locked typography decision for the new platform yet** — this is an open question to discuss with Christina.

When proposing typography:
- Stay legible at small sizes (mobile-first session capture means tutors are using this on phones)
- Avoid anything that codes as "ed-tech sterile" — TILT's brand is warmer than that
- Match the warmth of the off-white background and the mint primary

---

## Voice

When writing UI copy, error messages, or documentation that the school-side users will see:

- **Direct, not corporate.** "Your group is missing a current lesson" not "Group configuration incomplete — please review."
- **Respectful of expertise.** Coaches and tutors are professionals. Don't talk down to them.
- **Honest about uncertainty.** When the AI engine surfaces a recommendation, label it as a recommendation, show the evidence, and make the override path obvious.
- **No emoji in operational UI** unless Christina specifically asks for them. Christina uses them in casual chat but they don't belong in production UI for funder-visible surfaces.

---

## When in doubt

Ask Christina: **"Which brand palette should I use for this — operational TILT, or something else?"** This question takes 30 seconds and prevents an entire artifact from needing to be redone.
