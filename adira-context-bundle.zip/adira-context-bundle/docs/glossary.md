# Glossary — Adira Reads Terminology

Read this first if you encounter an unfamiliar term. TILT has accumulated a lot of internal vocabulary over five years.

---

## Organizations & people

| Term | Meaning |
|---|---|
| **TILT** | The Indy Learning Team — the nonprofit. Two staff: Christina Kelley (technical lead, fractional CTO) and Susan Appel (co-founder, executive lead). |
| **CK Consulting** | Christina Kelley Consulting — Christina's consulting LLC. The technical work for TILT runs through CK Consulting. |
| **Adira Reads** | The literacy intervention platform TILT operates. The thing we are rebuilding. |
| **Mapt Solutions** | An outside firm engaged via a Lilly Endowment planning grant. Produced Phase 1 and Phase 2 deliverables for TILT. |
| **Audrain Advising** | Outside tech strategy firm previously engaged. Produced an Operational Risk Baseline. |
| **Lilly Endowment** | The Indianapolis-based funder underwriting TILT's strategic planning. |

## Curriculum & instruction

| Term | Meaning |
|---|---|
| **UFLI** | University of Florida Literacy Institute. The structured-literacy curriculum TILT uses. Specifically: **UFLI Foundations**, a 128-lesson sequence. |
| **UFLI Foundations** | The full 128-lesson curriculum spanning K through ~Grade 3 mastery. |
| **The 128 lessons** | The canonical lesson sequence. Lesson numbers (L1–L128) are referenced everywhere. Some are review lessons that are excluded from certain denominators. |
| **Review lessons** | Lessons in the 128-lesson sequence that are reinforcement, not new content. Excluded from "current year goal progress" denominators. The full exclusion list: 35–41 (for G2+), 49, 53, 57, 59, 62, 71, 76, 79, 83, 88, 92, 97, 102, 104, 105, 106, 128. |
| **8-step lesson structure** | UFLI's lesson architecture: (1) Phonemic Awareness, (2) Visual Drill, (3) Auditory Drill, (4) Blending Drill, (5) New Concept, (6) Word Work, (7) Irregular Words / Heart Words, (8) Connected Text. |
| **MTSS** | Multi-Tiered System of Supports. Three tiers: Tier 1 (Core/Whole Class), Tier 2 (Supplemental/Small Group), Tier 3 (Intensive/Individual or Very Small Group). |
| **IREAD-3** | Indiana's mandatory third-grade reading proficiency assessment. TILT does predictive UFLI-to-IREAD mapping. |
| **Phonemic Awareness** | The ability to hear and manipulate individual sounds. Step 1 of the 8-step UFLI lesson. |
| **VCE** | Vowel-Consonant-E pattern (e.g., a_e, i_e, o_e, e_e, u_e). A specific UFLI skill section. |
| **Heart Words** | UFLI's term for high-frequency irregular words (sight words). Step 7 of the lesson. |
| **Connected Text** | Reading practice within a passage, not isolated words. Step 8. |
| **Sound Inventory** | A K-1 specific tracking tool for individual sound mastery. CHAW uses this. |
| **Fry Words** | The Fry sight-word lists. Tracked separately from UFLI lessons. |
| **OTR** | Opportunities to Respond. A pedagogical fidelity metric — target is 10+ per minute. |

## Assessments

| Term | Meaning |
|---|---|
| **UFLI Initial Assessment** | The diagnostic given at intake. The 1,007-student dataset (Feb 2026) is the canonical evidence base for the AI engine. |
| **10-skill screener** | A condensed diagnostic used for rapid screening. |
| **Diagnostic Framework** | Four-column structure: deficit type → reading error → spelling error → instructional response. Embedded in the UFLI_Lesson reference table. |

## Metrics & analytics

| Term | Meaning |
|---|---|
| **Big Four** | The four canonical metrics on the Friday Dashboard. Definitions are canonical and used in funder communications. (Full definitions in `data-model.md`.) |
| **Foundational Skills %** | Mastery of L1–L34 (the kindergarten foundation). Denominator = 34. |
| **Minimum Grade Skills %** | MTSS metric — cumulative through end of grade. KG = 34, G1 = 57, G2 = 67, G3+ = 107 lessons. |
| **Current Year Goal Progress** | This year's curriculum only, excluding review lessons. G1 = 23, G2 = 18, G3+ = 107 lessons. |
| **AG%** | **A**ctual **G**rowth percent. (Not "annual" — Christina confirmed this.) |
| **Banding** | Longitudinal student archetype assignment. Five archetypes derived from the 1,007-student dataset. |
| **Cliff alerts** | Known transition points where students historically drop off. Five canonical transitions, each with a hazard rate. |
| **Phase line** | An MTSS workflow concept — marks an instructional change point on a student's trajectory chart. |
| **Fidelity scoring** | Composite score across 8 metrics measuring instructional fidelity. Categories: Structural, Pedagogical, Engagement. Thresholds: Green/Yellow/Red. |
| **Priority Matrix** | A Friday Dashboard view that ranks groups by which need attention this week. |

## TILT-built systems (current state — to be replaced)

| Term | Meaning |
|---|---|
| **UFLI MAP** | The single source of truth for where each student is in the 128-lesson curriculum. Currently a sheet within each school's workbook. |
| **Tutor Input Form** | The session-capture form interventionists fill out after each session. |
| **Friday Dashboard** | The weekly operational view used by coaches. The "which groups need attention this week" tool. |
| **Monday Digest** | Weekly AI-authored coaching email, sent Monday morning. |
| **CoachingEmail.gs** | Current Apps Script that generates Gmail draft coaching emails per school site. |
| **Master Fidelity Dashboard** | v3.1 system correlating coaching observation fidelity with student outcomes. Uses Levenshtein fuzzy matching. |
| **TRAIN** | Tracker for **R**equests, **A**ctions & **I**ssues **N**otes. Internal change-request and school-notes tracking system. Two-tab Google Sheets architecture. |
| **CHAW Sound Tracker** | K-1 specific sound mastery tool. CHAW only. Tracks 29 KG sounds and 40 G1 sounds. |
| **Fry Word Tracker** | Group-level Fry word scoring with weekly data meeting emails. (FryTrackerCode.gs + WebApp.html.) |
| **ClipboardSheetGenerator** | Weekly printable one-pagers combining Sound Inventory and Fry Word data. |
| **IER** | **I**nstructional **E**nvironment **R**eview. Detects five classroom pattern types from observation data. |
| **Resequencing Workflow** | Automation that handles UFLI lesson reordering when groups regroup. |
| **PhoneHome.gs** | Snapshot system that writes school-level data back to a central location. |
| **MasterDashboard.gs** | Cross-school aggregation script. |
| **Setup Wizard** | School-onboarding wizard. Currently Apps Script (v3.x). Logic must port to the new platform. |

## Roles (in the new platform)

| Role | What they do |
|---|---|
| **Tutor / Interventionist** | Delivers UFLI sessions to students. Captures session data via mobile-first UI. |
| **Coach / Site Coordinator** | Observes tutors, runs weekly data meetings, manages groups. Primary user of the Friday Dashboard. |
| **School Admin** | School-side admin. Manages staff roster, schedules. |
| **TILT Admin** | Cross-school visibility. Christina and Susan. |
| **Parent** | Future role, not in MVP. |

## Acronyms quick reference

- **AG** — Actual Growth
- **CHAW** — Christel House West (school site)
- **CCA** — (school site, see `school-variations.md`)
- **GP** — Global Prep (school site)
- **IER** — Instructional Environment Review
- **MAP** — (in UFLI MAP context) the master lesson sequence sheet — not the NWEA MAP test
- **MTSS** — Multi-Tiered System of Supports
- **OTR** — Opportunities to Respond
- **RLS** — Row Level Security (PostgreSQL)
- **TRAIN** — Tracker for Requests, Actions & Issues Notes
- **UFLI** — University of Florida Literacy Institute
- **VCE** — Vowel-Consonant-E
