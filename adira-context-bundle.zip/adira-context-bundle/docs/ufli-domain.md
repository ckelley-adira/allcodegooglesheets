# UFLI Domain Knowledge

This is the curriculum and pedagogical knowledge encoded in the platform. **Do not modify these definitions without Christina's explicit approval.** They reflect five years of refinement and are used in funder communications.

---

## The 128-lesson sequence

UFLI Foundations is a structured-literacy curriculum from the University of Florida Literacy Institute. It consists of **128 sequenced lessons** progressing from phonemic awareness through advanced morphology.

### Lesson ranges by skill domain (partial — full mapping in source data)

| Range | Focus |
|---|---|
| L1–L34 | Single consonants, short vowels, foundational decoding (the "kindergarten foundation") |
| L35–L41 | Alphabet review (review lessons — excluded from G2+ year-progress denominators) |
| L42–L48 | FLSZ doubling rule, digraphs (ch, sh, th, ck) |
| L49 | Digraphs Review 1 (review lesson) |
| L50–L52 | wh, ph, ng, nk |
| L53 | Digraphs Review 2 (review lesson) |
| L54–L62 | VCE patterns (a_e, i_e, o_e, e_e, u_e), _ce, _ge |
| L63–L65 | Inflectional endings (-es, -ed, -ing) |
| L66–L68 | Closed/open syllable types |
| L69–L72 | tch, dge, long VCC patterns (-ild, -old, -ind, -olt, -ost) |
| L73–L76 | y as long i, y as long e, -le, ending patterns review |
| L77–L83 | R-controlled vowels (ar, or, ore, er, ir, ur) |
| L84–L92 | Vowel teams (ai, ay, ee, ea, ey, oa, ow, oe, ie, igh, oo, u, ew, ui, ue) |
| L93–L96 | au, aw, augh, oi, oy, ou, ow |
| L97+ | Advanced patterns, multisyllabic words, suffixes, prefixes |

### Review lessons (excluded from "current year goal" denominators)

**Full exclusion list:** 35, 36, 37, 38, 39, 40, 41 (for G2+), 49, 53, 57, 59, 62, 71, 76, 79, 83, 88, 92, 97, 102, 104, 105, 106, 128.

> **Why this matters:** when computing how many lessons a student has completed *of this year's curriculum*, review lessons are not counted in either the numerator or the denominator. Including them inflates progress numbers and produces wrong instructional decisions.

---

## The 8-step UFLI lesson structure

Every UFLI lesson follows the same 8-step structure. Fidelity scoring tracks completion and quality at each step.

1. **Phonemic Awareness** — oral, no print
2. **Visual Drill** — letter recognition
3. **Auditory Drill** — sound recognition
4. **Blending Drill** — combining sounds into words
5. **New Concept** — explicit instruction in the day's new skill
6. **Word Work** — guided practice
7. **Irregular Words (Heart Words)** — high-frequency irregular words
8. **Connected Text** — reading practice in context

---

## The four canonical metrics (Big Four) — exact definitions

These definitions are **canonical**. Use them in all UI labeling, all documentation, all funder communications. Do not paraphrase.

### Metric A: Foundational Skills %

- **What it measures:** Mastery of the kindergarten foundation (L1–L34).
- **Numerator:** Number of lessons in L1–L34 the student has passed.
- **Denominator:** 34.
- **Why it matters:** Without these, nothing above works. This is the minimum-viable decoding skill set.

### Metric B: Minimum Grade Skills % (MTSS metric)

- **What it measures:** Cumulative mastery through the end of the student's current grade.
- **Denominators by grade:**
  - **KG:** 34 lessons (L1–L34)
  - **G1:** 57 lessons (L1–L62, including alphabet review L35–L41)
  - **G2:** 67 lessons (L1–L83, including L38)
  - **G3+:** 107 lessons (L1–L128, excluding all 21 review lessons)
- **Why it matters:** Drives MTSS tier decisions. A G3 student below threshold here is the canonical Tier 3 candidate.

### Metric C: Current Year Goal Progress

- **What it measures:** Progress through *this year's* curriculum only, excluding review lessons.
- **Denominators by grade:**
  - **G1:** 23 lessons (L35–L62, excluding reviews 49, 53, 57, 59, 62)
  - **G2:** 18 lessons (L38 + L63–L83, excluding reviews 71, 76, 79, 83)
  - **G3+:** 107 lessons (uses same as Metric B)
- **Why it matters:** Tells you whether a student is on pace for grade-level expectations *this year*, independent of where they started.

### Metric D: Student Growth vs. Expected Slope (4-Week Rolling)

- **What it measures:** Whether the student's actual lesson-pass velocity matches the expected pace.
- **Window:** 4-week rolling.
- **Critical absence-handling rule:** Days marked **'A' (absent)** are **excluded** from the slope calculation, not counted as zeros. Counting absences as zero misdiagnoses presence problems as reading problems — this is the **Equity of Visibility** principle and it is non-negotiable.
- **Why it matters:** Catches students who are slowing down before they fall off a cliff.

### "AG%" — Actual Growth percent

This appears in the Grade Summary view and stands for **Actual Growth** (not "annual"). Christina explicitly confirmed this — do not relabel it.

---

## Banding archetypes

The banding logic assigns each student to one of **five archetypes** based on their longitudinal trajectory pattern, not their current absolute performance. The archetypes are derived from the **1,007-student UFLI Initial Assessment dataset (February 2026)**.

The full archetype profiles, including probability of IREAD-3 readiness for each, are in the source `.docx` (Section 5).

> **For the new platform:** the banding engine should be implementable as a scheduled job that re-bands students weekly. The five archetypes and their assignment criteria carry forward exactly. The 1,007-student dataset is the training/calibration source.

---

## Cliff alerts — five canonical transitions

These are empirically observed transition points where students historically drop off. Each has a hazard rate (probability of falling off if no intervention occurs). Full hazard rates are in the .docx Section 4.

The Friday Dashboard surfaces students approaching any of the five cliffs so coaches can intervene preemptively. **The cliffs are not aspirational alerts — they are based on observed dropout patterns from the historical data.**

---

## Fidelity scoring — 8 metrics, 3 categories

Composite fidelity scoring tracks instructional quality. Thresholds are Green / Yellow / Red.

### Structural Fidelity
| Metric | Green | Yellow | Notes |
|---|---|---|---|
| **Dosage** (% of scheduled minutes delivered) | ≥ 90% | ≥ 75% | Below 75% = Red |
| **Component Adherence** (% of 8 UFLI steps completed) | ≥ 80% | ≥ 60% | |
| **Script Fidelity** (% using explicit curriculum language) | ≥ 85% | ≥ 70% | |

### Pedagogical Fidelity
| Metric | Green | Yellow | Notes |
|---|---|---|---|
| **OTR per minute** (Opportunities to Respond) | ≥ 10 | ≥ 6 | Per-minute rate |
| **Correction Immediate** (% errors corrected immediately) | ≥ 90% | ≥ 75% | |
| **Choral Uniformity** (1–5 scale) | ≥ 4 | ≥ 3 | Subjective scale |

### Student Engagement
| Metric | Green | Yellow | Notes |
|---|---|---|---|
| **Participation** (% students actively engaged) | ≥ 90% | ≥ 75% | |
| (eighth metric in fidelity composite — confirm with Christina or check source) | | | |

> **Note:** the legacy code in `Building a school-wide literacy dashboard` defines the full set of thresholds in `CONFIG.THRESHOLDS`. Port that constant block exactly when implementing fidelity scoring.

---

## The diagnostic framework (UFLI_Lesson reference table)

Embedded in the `UFLI_Lesson` entity in the data model. Four columns per lesson:

1. **Deficit type** — what underlying skill the gap represents
2. **Reading error** — how the gap manifests when reading
3. **Spelling error** — how the gap manifests when spelling
4. **Instructional response** — what to teach to remediate

The Monday Digest uses this to generate per-student coaching recommendations: when an assessment surfaces a specific reading error, the system looks up the matching diagnostic framework row and surfaces the recommended instructional response.

---

## CHAW-specific: Sound Inventory & Fry Word tracking

CHAW (Christel House West) is the only K-1 site, so it has tools the other sites don't:

### Sound Tracker
- Tracks **29 KG sounds** and **40 G1 sounds**
- Group-level focus sound selection (3 lowest unmastered sounds per student, with the constraint that focus sounds must be from lessons ≤ the group's current lesson — "taught gate")
- Updates both the UFLI MAP and a Sound Inventory sheet
- Weekly digest emails

### Fry Word Tracker
- Group-level scoring against Fry sight word lists
- Weekly data meeting emails (HTML formatted)
- Web app interface (not a sheet form)

> **Open question for the new platform:** do these become first-class entities in the data model, or remain CHAW-specific extensions? See `data-model.md` open questions.

---

## IREAD-3 prediction

Indiana's mandatory third-grade reading assessment. TILT does logistic-regression-based UFLI-to-IREAD predictive mapping for Global Prep Academy, including bubble-student intervention plans and tier strategy validation.

The current model was developed against 69 third-grade students. **Open question:** port as-is, retrain on a larger dataset, or rebuild with a different methodology in the new platform.

---

## What "preserve what works" means in practice

When implementing any of the above in the new platform:

1. **Use the exact denominators, exact thresholds, exact lesson exclusions** documented here. Do not "round to a nicer number" or "simplify."
2. **Do not invent new metrics** without explicit approval. If you think a new metric would be useful, surface it as a question.
3. **Do not change the 8-step lesson structure.** It is curriculum-defined, not TILT-defined.
4. **Do not change the canonical metric names.** "Foundational Skills %" stays "Foundational Skills %" — not "Foundation %" or "Phonics %" or whatever feels cleaner.
5. **Do not rename "AG%"** even though it looks like an undefined acronym.
