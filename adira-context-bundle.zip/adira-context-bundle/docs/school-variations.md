# School Site Variations & Edge Cases

The current Adira Reads platform serves **six** school sites, scaling toward **8–12**. Each has slightly different naming conventions, grade bands, and operational quirks. This document captures everything Claude Code needs to know so the new platform doesn't accidentally hardcode assumptions that only work for one site.

---

## Canonical school list (current state)

These are the six sites, with their canonical names, short codes, and the naming variants they appear under in different sources. **The new platform should use UUIDs internally** (per the data model) but **must be able to ingest data from all of these naming variants** during migration.

| Code | Canonical Name | Variants seen in source data | Grade band | Notes |
|---|---|---|---|---|
| **CHW** | Christel House West | "CHW", "CHAW", "Christel House West" | K–8 (incl. K-1) | **Only site with K-1 cohort.** Has Sound Tracker + Fry Word Tracker. CHAW is the legacy spelling — both refer to the same school. |
| **SANKOFA** | Sankofa School of Success | "Sankofa", "SANKOFA", "Sankofa School of Success" | (confirm with Christina) | |
| **ADEL** | Adelante | "ADEL", "Adelante" | (confirm) | |
| **ALLEG** | Allegiant | "ALLEG", "Allegiant" | (confirm) | |
| **GP** | Global Prep | "GP", "Global Prep", "Global Prep Academy" | Includes G3 IREAD-3 cohort | The IREAD-3 predictive model work was done for Global Prep. |
| **CCA** | CCA | "CCA" | (confirm) | Has had Parent Conference Tools / HTML report generator built. |

> **CHW vs. CHAW:** Both refer to Christel House West. CHW is the newer code; CHAW appears in older code and conversation. **Treat them as identical.** When migrating data, normalize both to the canonical school_id.

## Sheet ID legacy reference

The current system stores each school as a separate Google Sheets workbook, each with its own sheet ID. These IDs are how data currently lives — the migration tooling will need to read from each:

```
CHW    → 16_4iUB9PI6ForpcCy0zP7uDpE59pLxFNy6Z5syYzezQ
SANKOFA → 1W7Z_FlOIes9rxtmtjp2JFuGRdPj97w_BXa0-FAUawwA
ADEL   → 1SWYEkNd9QEIxgjlNFiuHgKzNfBaJ9Znvfh-DczXpUGY
ALLEG  → 1pazQkYp6q6IUY5B-k7lKM7Bq9N0tUSADTIcgPLKi9Gs
GP     → 1LOksqc8LolgKcgIbgLvRdiW1E8v659EVwYKBjlaDdwQ
CCA    → 1H5rgxV_re8SMcnF_O47UqScEhMcirY8qEhmX9O6b1go
```

**Do not hardcode these in production code** — they're migration-time references only. The new platform stores `School` records in the database keyed by UUID.

---

## Naming convention drift — group names

Group names in the current system follow a loose convention that the new platform should formalize but also be tolerant of during migration. Real examples from the data:

```
KG Group 1
KG Group 4
G1 Group 1 Green
G2 Group M
G3 Group 1
G3 Group 2
G7 Group 2 - Afternoon Soar - Tia
```

**Pattern:** `(KG|G\d) Group (\w+)( (Green|Red|Blue|Yellow))?( - <interventionist name or descriptor>)?`

Things that drift:
- Some groups have a **color suffix**, some don't
- Some have an **interventionist name suffix** that changes when staff change
- Some use **letters instead of numbers** (`Group M`)
- Some have **descriptive suffixes** (`Afternoon Soar`)

### The fuzzy-match strategy that works (from production code)

When matching group names across data sources where the format has drifted, the legacy system uses a **tiered match strategy** that hits 27 of 28 in production:

1. **Exact match** (preferred)
2. **Key match** — extract `(grade)-(group identifier)-(color)` and match on the tuple
3. **Grade + number match** (ignore color when color is missing on one side)
4. **No match** (do not fall back to token similarity — it produces false positives on dissolved groups)

> **Lesson learned the hard way:** an earlier version included a "token similarity" tier (matching on interventionist names). It produced false positives where dissolved groups got matched to surviving groups via shared interventionist names. **Do not add this back.** When in doubt, return No Match and let a human resolve it.

### For the new platform

Group names should be **structured fields**, not free text. The `Group` entity should have:
- `grade` (enum: KG, G1, G2, ..., G8)
- `group_identifier` (string — usually a number, sometimes a letter)
- `color` (nullable enum)
- `display_name` (computed: `KG Group 1 Green`)
- `current_lesson` (FK to UFLI_Lesson)

The fuzzy-match logic only matters during the **initial data migration** from Sheets. New groups created in the platform will have clean structured fields.

---

## Student name variations & matching

Student names are the other major source of fuzzy-match pain. Real production observation: **out of 102 students joined across three sources, 91% matched exactly and 9 were fuzzy.** Common drift patterns:

| Pattern | Example | Fix |
|---|---|---|
| **Hyphenated last names** with inconsistent spacing | `Smith-Jones` vs. `Smith Jones` | Normalize hyphens to spaces, then token-sort |
| **Double-barreled surnames** (Latin American naming) | `Leonardo Rodriguez Rodriguez` (two surnames) vs. `Leonardo Rodriguez` (one) | Fix at the source — pick one canonical form and use it consistently |
| **Nicknames vs. legal names** | `Bobby` vs. `Robert` | Cannot auto-resolve. Requires a manual alias entry. |
| **Middle names or initials** | Present in one source, absent in another | Strip middle tokens before matching |
| **Typos** consistent within one sheet | `Jonh` consistently in one sheet | Fix at the source |

### For the new platform

Student records should have:
- `first_name`, `last_name`, `middle_name` (separate fields)
- `preferred_name` (nullable — handles Bobby/Robert)
- `student_external_id` (the ID like "K095" used in current data) — **this should be the join key going forward**, not the name

The `student_external_id` is the right answer to most fuzzy-match problems. The current system has these IDs (`K095` shows up in the example) but doesn't use them consistently as join keys. **Fix this in the new platform.**

---

## Mixed-grade groups

Some groups span multiple grades (e.g., a G2-G3 combined intervention group). The data model needs to handle this. The `Group_Membership` entity is the right place — students can belong to a group regardless of their own grade level.

The Big Four metrics use the **student's grade** to choose the correct denominator, not the group's grade. So a G3 student in a G2 group still has G3 denominators applied.

---

## Per-school feature variation

Not every school uses every TILT system. The new platform should support per-school feature flags:

| Feature | Currently used by |
|---|---|
| **Sound Tracker** | CHAW only (K-1 cohort) |
| **Fry Word Tracker** | CHAW only (K-1 cohort) |
| **IREAD-3 Prediction** | Global Prep (G3 cohort) |
| **Parent Conference HTML Reports** | CCA |
| **CoachingEmail.gs** | All sites (different configurations) |
| **Master Fidelity Dashboard** | All sites |
| **TRAIN (change request tracking)** | Internal — TILT only, not school-facing |

> **Implication for the data model:** the `School` entity should have a `features_enabled` JSONB column or a `School_Feature` join table. Avoid hardcoding "if school = CHAW" anywhere in the application code.

---

## Per-school data variation — what to expect during migration

Each school's workbook has slightly different sheet structures because they were built iteratively. The migration tooling needs to handle:

- **Different column orders** in the UFLI MAP
- **Different naming** for the Tutor Input Form responses tab (`Form Responses 6` vs. `Form Responses 9` etc.)
- **Different group naming conventions** (see above)
- **Some schools have stale/orphaned tabs** from earlier system versions
- **Data quality varies by school** — some have rigorous attendance tracking, others are spotty

**Strategy:** the migration should be **per-school** with a validation step that produces a report of unmatched students, malformed group names, missing assessments, etc. for human review before commit.

---

## Onboarding new schools (the scale path)

The current system requires Christina to manually set up each new school workbook (a multi-day process). The new platform must support **self-service school onboarding** via a Setup Wizard, ported from the current Apps Script logic.

The Setup Wizard handles:
1. School identity (name, address, contact info)
2. Grade bands offered
3. Staff invitations (coaches, tutors)
4. Initial student roster import
5. Group creation
6. UFLI starting-lesson assignment per group
7. Schedule setup
8. Feature flag selection (Sound Tracker? Fry? IREAD-3?)

A school admin should be able to complete this **without TILT involvement**. This is the key to scaling beyond 12 sites.

---

## Things that vary that you probably wouldn't guess

- **Tutor naming conventions** — "Ms. Smith" vs. "Smith, M." vs. "Maria Smith" — same person, different formats across sources. Levenshtein at threshold 0.8 catches most cases (chosen empirically).
- **School year start dates** — not all schools start the same week. The "current year goal" denominators reset on a per-school basis.
- **Session lengths** — scheduled minutes per session vary by school and by group. Dosage % calculations need the school-specific scheduled value, not a hardcoded constant.
- **Coach observation frequency** — varies by school. Don't assume weekly observations exist for every group.
