# Architectural Decisions

A running log of decisions that have been made (so they don't get relitigated) and decisions that are still **open** (so they don't get assumed).

> **Rule:** if a decision isn't in this file or in the Future State Data Model .docx, it is **not yet made**. Do not invent.

---

## Decided

### D-001: Multi-tenant SaaS, single deployment
**Decision:** One application instance serves all school tenants. School isolation is enforced at the database layer.
**Why:** The current N-deployments-per-change model is the operational pain point being fixed. A single deployment is also the only economically viable model for a 2-person nonprofit at 8–12 sites.
**Rejected alternative:** One instance per school. Cost and operational overhead make this untenable.

### D-002: PostgreSQL with Row Level Security for tenant isolation
**Decision:** Tenant isolation enforced via PostgreSQL RLS, not application-layer filtering.
**Why:** Defense in depth — application bugs cannot leak data across schools because the database itself will not return cross-school rows. This is the only model that satisfies the "data sovereignty above all" principle credibly.
**Rejected alternative:** Application-layer filtering with WHERE clauses. Too easy to bypass via a missed clause in a single endpoint.

### D-003: Five roles in the role layer
**Decision:** Tutor, Coach, School Admin, TILT Admin, Parent (future / post-MVP).
**Why:** Maps to the actual operational roles in TILT's school partnerships. Parent is deferred to post-MVP because there's no MVP-critical parent-facing feature.

### D-004: Append-only audit log
**Decision:** `Audit_Log` table has no UPDATE or DELETE permissions granted to the application user. Append-only at the database level.
**Why:** Compliance, debugging, and accountability all depend on the log being trustworthy. If the application could rewrite it, it provides no guarantees.

### D-005: Human decision authority over AI
**Decision:** No AI recommendation ever modifies student records directly. AI writes to a recommendation queue; humans process the queue. All AI actions logged in audit log with `AI_RECOMMENDATION_*` action types.
**Why:** This is a hard ethical line — the system is supporting humans, not replacing them. Also satisfies funder and partner-school expectations.

### D-006: Preserve the analytical framework exactly
**Decision:** Big Four metrics, banding archetypes, cliff alerts, conditional probability chains, fidelity scoring — all carry forward unchanged. The container changes; the content does not.
**Why:** Five years of refinement and a 1,007-student dataset back the current framework. Re-deriving it would be expensive and would invalidate funder communications that already use these definitions.

### D-007: Self-service school onboarding via Setup Wizard
**Decision:** A school admin must be able to onboard their school without TILT involvement.
**Why:** This is the key scale enabler past 12 sites. Christina cannot manually onboard every new partner school.
**Implication:** The Setup Wizard logic from the current Apps Script v3.x ports forward (concept and steps), not the code.

### D-008: Group entity uses structured fields, not free-text names
**Decision:** `Group` has `grade`, `group_identifier`, `color`, and `display_name` as separate columns. Display name is computed.
**Why:** The fuzzy-match pain in the current system is entirely caused by free-text group names drifting. Structured fields eliminate the problem at the source for new groups.
**Note:** Migration tooling still needs the legacy fuzzy-match strategy to import existing Sheets data.

### D-009: Student external ID is the primary join key
**Decision:** Each student has a `student_external_id` (e.g., `K095`) that is the canonical join key going forward, not the name.
**Why:** Name-based joining produces 9% fuzzy matches in real data and cannot resolve nicknames or double-barreled surnames. IDs are deterministic.

### D-010: Doc convention — file headers, JSDoc, inline comments
**Decision:** Code documentation follows Christina's `code-docs` skill conventions: file-level header blocks, JSDoc on every non-trivial function, inline comments for non-obvious logic only.
**Why:** Christina is the sole technical lead today. Future maintainers (or future-Christina) need to understand the "why," not just the "what." She values exhaustive docs.
**Reference:** Full convention in the original `code-docs` skill. Port the conventions to whatever language(s) the new stack uses.

### D-011: Never abbreviate "Christina Kelley" to "Kelley"
**Decision:** Christina's full name is Christina Kelley. CK Consulting = Christina Kelley Consulting. Never use "Kelley" alone in any document, code comment, or commit message.

### D-012: Equity of Visibility — absences are not zeros
**Decision:** Days marked 'A' (absent) are excluded from growth slope calculations, never counted as zeros.
**Why:** Counting absences as zero misdiagnoses presence problems as reading problems. This is the canonical Equity of Visibility principle and is non-negotiable.

---

## Open

### O-001: Tech stack — frontend, backend, hosting
**Status:** Not yet locked.
**The data model assumes PostgreSQL** (from D-002) but the application stack is open. Christina has not committed to Next.js, Remix, Rails, Django, or anything else yet.
**Constraints to weigh when deciding:**
- Christina is self-taught; pick something she can read and modify
- Two-person ops budget — managed services preferred
- Must support PostgreSQL with RLS natively
- Must support nonprofit/education pricing tiers
- Sentry + Posthog mentioned as the monitoring/analytics stack in the .docx
- Vercel + Railway mentioned as the hosting recommendation in the .docx
**Action:** Discuss with Christina before writing any application code.

### O-002: AI provider for the Coaching Intelligence module
**Status:** Open. Anthropic Claude is the obvious candidate given Christina's existing fluency, but cost, data residency, and BAA considerations are unresolved.

### O-003: Sound Inventory and Fry Word Tracker — first-class or feature-flagged?
**Status:** Open. Currently CHAW-only. Question: do these become first-class entities (always present, always queryable) or feature-flagged extensions (only loaded when a school enables them)?
**Impact:** Affects schema design for `Sound_Inventory_Record` and `Fry_Word_Record`.

### O-004: IREAD-3 prediction model
**Status:** Open. Three options: (a) port the existing logistic regression as-is, (b) retrain on a larger dataset when one becomes available, (c) rebuild with a different methodology.
**Currently:** Built against 69 third-grade students from Global Prep.

### O-005: Retention policies — Reports and Audit Log
**Status:** Open.
- Reports: scheduled reports may have a 90-day retention default per the .docx, but on-demand reports? Unclear.
- Audit Log: indefinite, but should there be a cold-storage tier after N years?

### O-006: Backup and disaster recovery cadence
**Status:** Open. The .docx mentions "backup" as a topic in Section 2 but doesn't lock the cadence or the recovery objectives.

### O-007: Monday.com — keep in the loop or retire?
**Status:** Open. The current system has Monday.com integration for student unenrollment workflow and assessment boards. The new platform could absorb this and retire the integration, or keep Monday.com as a system of record for some workflows.

### O-008: TRAIN — separate tool or integrated module?
**Status:** Open. TRAIN is the internal change-request tracker. It could stay as a Google Sheets tool outside the platform, or be rebuilt as a simple internal module.

### O-009: Migration phasing
**Status:** Open. The Mapt Solutions 51-item build plan exists; an actual sequencing decision for the new platform has not been made. **Do not assume an order without asking Christina.**

### O-010: Parent role — when?
**Status:** Deferred to post-MVP. No MVP feature requires parent access. Revisit after launch.

### O-011: Mobile strategy
**Status:** Open. The .docx says "mobile-first tutor UI" for session capture, but doesn't specify whether that's a responsive web app, a PWA, or native mobile. Christina's preference is unknown.

### O-012: Eighth fidelity metric
**Status:** Need to confirm with Christina or check the source CONFIG.THRESHOLDS block. The fidelity composite has 8 metrics across 3 categories; 7 are documented in `ufli-domain.md` and the 8th needs verification.

---

## How to add to this file

When a new decision is made in conversation with Christina, add it as a new `D-NNN` entry with:
- **Decision:** what was decided
- **Why:** the reasoning
- **Rejected alternative** (if any): what was considered and rejected, and why

When something open gets decided, **move it from Open to Decided** rather than deleting the open entry. The history of when something was decided is itself useful.
